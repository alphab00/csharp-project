using Microsoft.EntityFrameworkCore;
using SimpleCSharpProject.Models;

namespace SimpleCSharpProject.Data
{
    public class SimpleCSharpProjectContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=SimpleCSharpProject.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("User");
        }
    }
}
