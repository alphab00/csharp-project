using Microsoft.AspNetCore.Mvc;
using SimpleCSharpProject.Models;
using System.Collections.Generic;

namespace SimpleCSharpProject.Controllers
{
    public class TrafficController : Controller
    {
        [HttpPost]
        public IActionResult ProcessInput(string inputField, string inputMonth, string inputYear, 
        string inputFirst, string inputLast)
        {
            BusinessModel businessModel = new BusinessModel();
            List<User> users = businessModel.GetUsers(inputField, inputMonth, inputYear, 
            inputFirst, inputLast);

            return View("ResultPage", users);
        }
    }
}
