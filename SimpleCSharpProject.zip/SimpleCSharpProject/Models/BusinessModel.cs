using SimpleCSharpProject.Data;
using System.Collections.Generic;
using System.Linq;

namespace SimpleCSharpProject.Models
{
    public class BusinessModel
    {
        public List<User> GetUsers(string inputField, string inputMonth, 
        string inputYear, string inputFirst, string inputLast)
        {
            using (var context = new SimpleCSharpProjectContext())
            {
                return context.Users
                              .Where(u => u.CreditCardNumber == (inputField)
                              && u.ExpMonth ==(inputMonth)
                              && u.ExpYear ==(inputYear)
                              && u.FirstName == (inputFirst)
                              && u.LastName == (inputLast))
                              .ToList();
            }
        }
    }
}
