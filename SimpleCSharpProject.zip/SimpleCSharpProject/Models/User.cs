namespace SimpleCSharpProject.Models
{
    public class User
    {
        public int Id { get; set; }
        public string? CreditCardNumber { get; set; }
        public string? ExpMonth { get; set; }
        public string? ExpYear { get; set; }
        public string? LastName { get; set; }
        public string? FirstName { get; set; }
    }
}
